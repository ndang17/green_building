<style>
    .nav-pills>li>a {
        border-radius: 0px;
        /*border-right: 1px solid #ccc;*/
        border-right: 1px solid #ccc;
    }
    .nav-pills>li.active>a, .nav-pills>li.active>a:focus, .nav-pills>li.active>a:hover {
        background-color: #607D8B;
    }
    .nav-pills>li+li {
        margin-left: 0px;
    }
</style>
<div class="row">
    <div class="col-md-12">
        <div class="thumbnail">
            <ul class="nav nav-pills">
                <li role="presentation" class=""><a href="http://localhost:8080/f/admin/master/add-question"><i class="fa fa-th-large margin-right"></i> List User Test</a></li>
            </ul>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="thumbnail">
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>No</th>
                    <th>Name</th>
                    <th>Jabatan</th>
                    <th>Email</th>
                    <th>Pekerjaan</th>
                    <th>Proyek</th>
                    <th>Lokasi</th>
                    <th>Luas Lahan</th>
                    <th>Luas Bangunan</th>
                </tr>
                </thead>
            </table>
        </div>
    </div>
</div>