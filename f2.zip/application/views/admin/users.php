
<div class="row">
    <div class="col-md-12">
        <div class="thumbnail" style="min-height: 100px;">
        </div>
    </div>
</div>